/*
 *
 *  This file is part of MUMPS 5.9.0, released
 *  on Tue Apr 28 13:05:59 UTC 2026
 *
 *
 *  Copyright 1991-2026 CERFACS, CNRS, ENS Lyon, INP Toulouse, Inria,
 *  Mumps Technologies, University of Bordeaux.
 *
 *  This version of MUMPS is provided to you free of charge. It is
 *  released under the CeCILL-C license 
 *  (see doc/CeCILL-C_V1-en.txt, doc/CeCILL-C_V1-fr.txt, and
 *  https://cecill.info/licences/Licence_CeCILL-C_V1-en.html)
 *
 */
#ifndef MUMPS_CONFIG_FILE_C_H
#define MUMPS_CONFIG_FILE_C_H
#include "mumps_common.h"
#define MUMPS_GET_CONFIG_FILE_C \
    F_SYMBOL(get_config_file_c,GET_CONFIG_FILE_C)
void MUMPS_CALL
MUMPS_GET_CONFIG_FILE_C(MUMPS_INT *len_config_file, char* config_file, mumps_ftnlen l1);
#define MUMPS_CONFIG_FILE_RETURN_C \
    F_SYMBOL(config_file_return_c,CONFIG_FILE_RETURN_C)
void MUMPS_CALL
MUMPS_CONFIG_FILE_RETURN_C();
#endif /* MUMPS_CONFIG_FILE_C_H */
